# Pinball-Pokemon Sapphire

## TEAM MEMBERS:

  * Sergio Corona
  * Yunqian Ao
  * Enric Arxer
  * Miguel Rodriguez

## CONTROLS:

  * WASD: Move the player
  
## DEBUG FEATURES:

  * F9: Change betwen player modes(only one implemented)


## LINK TO OUR GITHUB:

https://github.com/Luxary-92/Physics-II_Worms-Engine